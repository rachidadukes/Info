using System.Security.Claims;
using Encore.Security.AspNetCore;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Authorization;

namespace EncoreAuthDemo.Components.Pages.Authentication;

public partial class SecurityProfile
{
    [CascadingParameter]
    private Task<AuthenticationState> AuthenticationStateTask { get; set; } = default!;

    private ClaimsPrincipal? User { get; set; }

    private string EmployeeId => ReadClaim(EncoreClaimTypes.EmployeeId);

    private string DisplayName => ReadClaim(EncoreClaimTypes.DisplayName);

    private string MatchedAdGroup => ReadClaim(EncoreClaimTypes.MatchedAdGroup);

    private string Role => User?.FindFirst(ClaimTypes.Role)?.Value ?? string.Empty;

    private string AuthorityLevel => ReadClaim(EncoreClaimTypes.LegacyAuthorityLevel);

    protected override async Task OnInitializedAsync()
    {
        User = (await AuthenticationStateTask).User;
    }

    private string ReadClaim(string claimType)
    {
        return User?.FindFirst(claimType)?.Value ?? string.Empty;
    }
}
