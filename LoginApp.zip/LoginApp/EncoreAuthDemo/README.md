# Encore Auth Demo

Standalone .NET 9 Blazor proof of concept for the legacy Encore authentication and authorization model.

## Purpose

The app demonstrates:

- Employee ID and network password login.
- Active Directory authentication through LDAP.
- Active Directory group membership retrieval.
- Encore group to role mapping.
- ClaimsPrincipal creation.
- Blazor authentication state.
- Role-protected pages for Admin, Supervisor, and Teller.
- A diagnostic security profile page that shows mapped demo metadata.

## Project Shape

- `Encore.Security.Core` contains authentication contracts, user models, authorization roles, policies, and group mapping.
- `Encore.Security.ActiveDirectory` contains the LDAP implementation and Active Directory configuration model.
- `Encore.Security.AspNetCore` contains claims creation, cookie and policy registration, and login/logout endpoints.
- `EncoreAuthDemo` is the Blazor host and owns environment configuration, data-protection storage, and UI.
- `Components/Pages/Authentication/` contains the login, access-denied, and security-profile pages.

The Blazor pages remain in the host so each consuming application can control its own presentation. The three security libraries can be packaged as private NuGet packages for use by separate .NET 9 solutions.

## Host Integration

Reference `Encore.Security.AspNetCore` and `Encore.Security.Core`, then register and map the shared functionality:

```csharp
builder.Services.AddEncoreSecurity(
    builder.Configuration,
    options => options.Cookie.Name = "YourApplication.Auth");

app.UseAuthentication();
app.UseAuthorization();
app.UseAntiforgery();
app.MapEncoreAuthenticationEndpoints();
```

Each host supplies its own `ActiveDirectory` and `EncoreAuthorization` configuration sections.

## Configuration

Set these values in `appsettings.json`, user secrets, or environment variables before testing against Active Directory:

- `ActiveDirectory:Server`
- `ActiveDirectory:Port`
- `ActiveDirectory:UseSsl`
- `ActiveDirectory:Domain`
- `ActiveDirectory:BindUserNameFormat`
- `ActiveDirectory:SearchBaseDn`
- `EncoreAuthorization:GroupMappings`

The included group mappings preserve the legacy Encore relationship:

- Admin -> AuthorityLevel 1
- Supervisor -> AuthorityLevel 4
- Teller -> AuthorityLevel 5

The app uses the configured mapping order as precedence when a user belongs to more than one recognized Encore group.

## Running

```powershell
dotnet build EncoreAuthDemo.slnx
dotnet run --project EncoreAuthDemo\EncoreAuthDemo.csproj --launch-profile https
```

If the local HTTPS developer certificate is missing, create one with:

```powershell
dotnet dev-certs https --trust
```

Use HTTPS when entering a real network password.

## Security Notes

- The password is used only for the LDAP bind and is cleared from the login form model after authentication.
- Passwords are not logged, stored in a database, written to files, stored in browser storage, or retained in claims.
- Authorization is enforced on protected pages with standard ASP.NET Core role checks.
- `AuthorityLevel` is retained only as legacy metadata in a claim and on the diagnostic page.
- Development Data Protection keys are generated under `App_Data/DataProtectionKeys`; that folder is ignored by `.gitignore`.
