namespace Encore.Security.Core.Models;

public sealed class EncoreUser
{
    public string EmployeeId { get; init; } = string.Empty;

    public string DisplayName { get; init; } = string.Empty;

    public string DistinguishedName { get; init; } = string.Empty;

    public string MatchedAdGroup { get; init; } = string.Empty;

    public string Role { get; init; } = string.Empty;

    public int LegacyAuthorityLevel { get; init; }

    public IReadOnlyList<string> ActiveDirectoryGroups { get; init; } = [];
}
