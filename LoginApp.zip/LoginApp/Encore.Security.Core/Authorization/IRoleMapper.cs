namespace Encore.Security.Core.Authorization;

public interface IRoleMapper
{
    EncoreRoleMatch? Map(IReadOnlyCollection<string> activeDirectoryGroups);
}
