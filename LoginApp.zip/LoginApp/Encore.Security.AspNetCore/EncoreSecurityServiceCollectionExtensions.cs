using Encore.Security.ActiveDirectory;
using Encore.Security.Core.Authentication;
using Encore.Security.Core.Authorization;
using Encore.Security.Core.Options;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Encore.Security.AspNetCore;

public static class EncoreSecurityServiceCollectionExtensions
{
    public static IServiceCollection AddEncoreSecurity(
        this IServiceCollection services,
        IConfiguration configuration,
        Action<CookieAuthenticationOptions>? configureCookie = null)
    {
        services.Configure<ActiveDirectoryOptions>(
            configuration.GetSection(ActiveDirectoryOptions.SectionName));
        services.Configure<EncoreAuthorizationOptions>(
            configuration.GetSection(EncoreAuthorizationOptions.SectionName));

        services.AddSingleton<IRoleMapper>(serviceProvider =>
            new EncoreRoleMapper(
                serviceProvider.GetRequiredService<IOptions<EncoreAuthorizationOptions>>().Value));
        services.AddScoped<IAuthenticationService>(serviceProvider =>
            new ActiveDirectoryAuthenticationService(
                serviceProvider.GetRequiredService<IOptions<ActiveDirectoryOptions>>().Value,
                serviceProvider.GetRequiredService<IRoleMapper>(),
                serviceProvider.GetRequiredService<ILogger<ActiveDirectoryAuthenticationService>>()));

        services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
            .AddCookie(options =>
            {
                options.Cookie.HttpOnly = true;
                options.Cookie.SameSite = SameSiteMode.Strict;
                options.Cookie.SecurePolicy = CookieSecurePolicy.Always;
                options.LoginPath = "/login";
                options.LogoutPath = "/logout";
                options.AccessDeniedPath = "/access-denied";
                options.SlidingExpiration = true;
                options.ExpireTimeSpan = TimeSpan.FromMinutes(30);
                configureCookie?.Invoke(options);
            });

        services.AddAuthorization(options =>
        {
            options.AddPolicy(EncorePolicies.AdminOnly, policy => policy.RequireRole(EncoreRoles.Admin));
            options.AddPolicy(EncorePolicies.SupervisorOnly, policy => policy.RequireRole(EncoreRoles.Supervisor));
            options.AddPolicy(EncorePolicies.TellerOnly, policy => policy.RequireRole(EncoreRoles.Teller));
        });

        return services;
    }
}
