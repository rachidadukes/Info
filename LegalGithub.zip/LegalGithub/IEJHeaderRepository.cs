using LegalHoldAdmin.Models;

namespace LegalHoldAdmin.Data;

public interface IEJHeaderRepository
{
    Task<PagedResult<EJHeaderRecord>> LoadPageAsync(
        string accessNumber,
        int skip,
        int pageSize,
        string? orderBy = null,
        CancellationToken cancellationToken = default);
}
