using LegalHoldAdmin.Models;

namespace LegalHoldAdmin.Data;

public interface IEJHeaderRepository
{
    Task<List<EJHeaderRecord>> LoadAsync(
        string accessNumber,
        int rowLimit = 100,
        CancellationToken cancellationToken = default);
}
