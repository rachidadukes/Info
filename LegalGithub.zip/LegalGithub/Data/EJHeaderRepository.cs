using LegalHoldAdmin.Models;
using Microsoft.Data.SqlClient;
using System.Data;

namespace LegalHoldAdmin.Data;

public sealed class EJHeaderRepository : IEJHeaderRepository
{
    private readonly IConfiguration _configuration;
    private readonly ILogger<EJHeaderRepository> _logger;

    public EJHeaderRepository(IConfiguration configuration, ILogger<EJHeaderRepository> logger)
    {
        _configuration = configuration;
        _logger = logger;
    }

    public async Task<List<EJHeaderRecord>> LoadAsync(
        string accessNumber,
        int rowLimit = 100,
        CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(accessNumber))
        {
            throw new ArgumentException("Access number is required.", nameof(accessNumber));
        }

        if (accessNumber.Trim().Length > 14)
        {
            throw new ArgumentException("Access number cannot exceed 14 characters.", nameof(accessNumber));
        }

        var normalizedAccessNumber = accessNumber.Trim().PadLeft(14, '0');
        var tableName = GetConfiguredTableName();
        var connectionString = _configuration.GetConnectionString("LegalHoldAdmin_DEV")
            ?? throw new InvalidOperationException("Missing connection string: ConnectionStrings:LegalHoldAdmin_DEV");
        var results = new List<EJHeaderRecord>();

        await using var connection = new SqlConnection(connectionString);
        await using var command = new SqlCommand(
            $"SELECT TOP (@RowLimit) * FROM {tableName} WHERE [AccessNo] = @AccessNo ORDER BY [RecordID] DESC",
            connection);
        command.Parameters.Add("@RowLimit", SqlDbType.Int).Value = Math.Clamp(rowLimit, 1, 500);
        command.Parameters.Add("@AccessNo", SqlDbType.NVarChar, 14).Value = normalizedAccessNumber;

        try
        {
            await connection.OpenAsync(cancellationToken);
            await using var reader = await command.ExecuteReaderAsync(cancellationToken);

            while (await reader.ReadAsync(cancellationToken))
            {
                results.Add(new EJHeaderRecord
                {
                    RecordID = GetValue(reader, "RecordID"),
                    BranchNumber = GetValue(reader, "BranchNumber"),
                    BranchID = GetValue(reader, "BranchID"),
                    UserID = GetValue(reader, "userID"),
                    TranNo = GetValue(reader, "TranNo"),
                    TranName = GetValue(reader, "TranName"),
                    TranID = GetValue(reader, "TranID"),
                    EJTime = GetValue(reader, "EJTime"),
                    CalendarDate = GetValue(reader, "CalendarDate"),
                    EnterpriseStatus = GetValue(reader, "EnterpriseStatus"),
                    HostStatus = GetValue(reader, "HostStatus"),
                    HostApproved = GetValue(reader, "HostApproved"),
                    HostTimeOut = GetValue(reader, "HostTimeOut"),
                    ForwardToHost = GetValue(reader, "ForwardToHost"),
                    ForwardToHostApproved = GetValue(reader, "ForwardToHostApproved"),
                    ForwardToHostTimeOut = GetValue(reader, "ForwardToHostTimeOut"),
                    CustomerID = GetValue(reader, "CustomerID"),
                    MultiTranNumber = GetValue(reader, "MultiTranNumber"),
                    AccountNumber = GetValue(reader, "AccountNumber"),
                    TranAmount = GetValue(reader, "TranAmount"),
                    Passbook = GetValue(reader, "Passbook"),
                    BeginTime = GetValue(reader, "BeginTime"),
                    CashBoxID = GetValue(reader, "CashBoxID"),
                    CashAccumInd = GetValue(reader, "CashAccumInd"),
                    DeferredStatus = GetValue(reader, "DeferredStatus"),
                    TranCommitted = GetValue(reader, "TranCommitted"),
                    SigCaptured = GetValue(reader, "SigCaptured"),
                    AccessNo = GetValue(reader, "AccessNo")
                });
            }
        }
        catch (SqlException ex)
        {
            _logger.LogError(ex, "Failed to load EJHeader table {TableName}", tableName);
            throw new InvalidOperationException($"Database error while loading {tableName}: {ex.Message}", ex);
        }

        return results;
    }

    private string GetConfiguredTableName()
    {
        var configured = _configuration["EJHeader:TableName"] ?? "dbo.EJHeader";
        var parts = configured.Split('.', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

        if (parts is not { Length: >= 1 and <= 2 } ||
            parts.Any(part => part.Any(ch => !char.IsLetterOrDigit(ch) && ch != '_')))
        {
            throw new InvalidOperationException(
                "EJHeader:TableName must be a one- or two-part SQL identifier, such as dbo.EJHeader.");
        }

        return string.Join(".", parts.Select(part => $"[{part}]"));
    }

    private static object? GetValue(SqlDataReader reader, string columnName)
    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? null : reader.GetValue(ordinal);
    }
}
