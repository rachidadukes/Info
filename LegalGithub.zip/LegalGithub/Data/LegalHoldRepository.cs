using LegalHoldAdmin.Models;
using Microsoft.Data.SqlClient;
using System.Data;

namespace LegalHoldAdmin.Data;

public sealed class LegalHoldRepository : ILegalHoldRepository
{
    private readonly IConfiguration _configuration;
    private readonly ILogger<LegalHoldRepository> _logger;

    public LegalHoldRepository(IConfiguration configuration, ILogger<LegalHoldRepository> logger)
    {
        _configuration = configuration;
        _logger = logger;
    }

    public Task<List<LegalHoldResult>> SearchLegalHoldsAsync(
        LegalHoldSearchRequest request,
        CancellationToken cancellationToken = default)
    {
        var procedure = _configuration["LegalHold:SearchLegalHoldProcedure"] ?? "dbo.Search_EJLegalHold";
        return ExecuteSearchProcedureAsync(procedure, request, cancellationToken);
    }

    public Task<List<CustomerSearchResult>> SearchCustomersAsync(
        LegalHoldSearchRequest request,
        CancellationToken cancellationToken = default)
    {
        var procedure = _configuration["LegalHold:SearchCustomerProcedure"] ?? "dbo.Search_EJLegalHold_Customers";
        return ExecuteCustomerSearchProcedureAsync(procedure, request, cancellationToken);
    }

    public async Task SaveLegalHoldAsync(
        LegalHoldEditModel model,
        CancellationToken cancellationToken = default)
    {
        if (_configuration.GetValue<bool>("LegalHold:ReadOnlyMode"))
        {
            throw new InvalidOperationException(
                "ReadOnlyMode is enabled. Set LegalHold:ReadOnlyMode to false only after you are ready to test inserts/updates.");
        }

        var procedure = _configuration["LegalHold:InsertUpdateProcedure"] ?? "dbo.INS_UPD_EJLegalHold";
        var connectionString = GetConnectionString();

        await using var connection = new SqlConnection(connectionString);
        await using var command = new SqlCommand(procedure, connection)
        {
            CommandType = CommandType.StoredProcedure
        };

        command.Parameters.Add("@IsInsert", SqlDbType.Bit).Value = model.IsInsert;
        command.Parameters.Add("@AccessNo", SqlDbType.VarChar, 30).Value = (object?)model.AccessNumber ?? DBNull.Value;
        command.Parameters.Add("@Name", SqlDbType.VarChar, 30).Value = (object?)model.Name ?? DBNull.Value;
        command.Parameters.Add("@StartDate", SqlDbType.DateTime2).Value = model.StartDate;
        command.Parameters.Add("@EndDate", SqlDbType.DateTime2).Value = (object?)model.EndDate ?? DBNull.Value;
        command.Parameters.Add("@Active", SqlDbType.Bit).Value = model.Active;
        command.Parameters.Add("@ID", SqlDbType.Int).Value = model.ID == 0 ? -1 : model.ID;

        try
        {
            await connection.OpenAsync(cancellationToken);
            await command.ExecuteNonQueryAsync(cancellationToken);
        }
        catch (SqlException ex)
        {
            _logger.LogError(ex, "Failed to execute {Procedure}", procedure);
            throw new InvalidOperationException(ex.Message, ex);
        }
    }

    private async Task<List<LegalHoldResult>> ExecuteSearchProcedureAsync(
        string procedure,
        LegalHoldSearchRequest request,
        CancellationToken cancellationToken)
    {
        var results = new List<LegalHoldResult>();
        var connectionString = GetConnectionString();

        await using var connection = new SqlConnection(connectionString);
        await using var command = new SqlCommand(procedure, connection)
        {
            CommandType = CommandType.StoredProcedure
        };

        // Clay said the search procs accept account number, access number, first name, last name, or any combination.
        // If the actual parameter names in EncoreUnit differ, adjust only these four names here.
        AddOptionalText(command, "@AccountNo", request.AccountNumber, 50);
        AddOptionalText(command, "@HostCIFKey", request.AccessNumber, 50);
        AddOptionalText(command, "@FirstName", request.FirstName, 40);
        AddOptionalText(command, "@LastName", request.LastName, 30);

        try
        {
            await connection.OpenAsync(cancellationToken);
            await using var reader = await command.ExecuteReaderAsync(cancellationToken);

            while (await reader.ReadAsync(cancellationToken))
            {
                results.Add(ReadLegalHoldResult(reader));
            }
        }
        catch (SqlException ex)
        {
            _logger.LogError(ex, "Failed to execute {Procedure}", procedure);
            throw new InvalidOperationException($"Database error while executing {procedure}: {ex.Message}", ex);
        }

        return results;
    }

    private async Task<List<CustomerSearchResult>> ExecuteCustomerSearchProcedureAsync(
        string procedure,
        LegalHoldSearchRequest request,
        CancellationToken cancellationToken)
    {
        var results = new List<CustomerSearchResult>();
        var connectionString = GetConnectionString();

        await using var connection = new SqlConnection(connectionString);
        await using var command = new SqlCommand(procedure, connection)
        {
            CommandType = CommandType.StoredProcedure
        };

        AddOptionalText(command, "@AccountNo", request.AccountNumber, 50);
        AddOptionalText(command, "@HostCIFKey", request.AccessNumber, 50);
        AddOptionalText(command, "@FirstName", request.FirstName, 40);
        AddOptionalText(command, "@LastName", request.LastName, 30);

        try
        {
            await connection.OpenAsync(cancellationToken);
            await using var reader = await command.ExecuteReaderAsync(cancellationToken);

            while (await reader.ReadAsync(cancellationToken))
            {
                results.Add(new CustomerSearchResult
                {
                    CustomerID = GetValue<int?>(reader, "CustomerID") ?? 0,
                    FirstName = GetValue<string?>(reader, "FirstName") ?? string.Empty,
                    MiddleName = GetValue<string?>(reader, "MiddleName") ?? string.Empty,
                    LastName = GetValue<string?>(reader, "LastName") ?? string.Empty,
                    AccessNumber = GetValue<string?>(reader, "AccessNo", "HostCIFKey") ?? string.Empty,
                    AccountNumber = GetValue<string?>(reader, "AccountNumber") ?? string.Empty,
                    SocialSecurityNumber = GetValue<string?>(
                        reader,
                        "SSNTIN",
                        "SSN_TIN",
                        "SSN",
                        "SocialSecurityNumber") ?? string.Empty
                });
            }
        }
        catch (SqlException ex)
        {
            _logger.LogError(ex, "Failed to execute {Procedure}", procedure);
            throw new InvalidOperationException($"Database error while executing {procedure}: {ex.Message}", ex);
        }

        return results;
    }

    private static void AddOptionalText(SqlCommand command, string name, string? value, int size)
    {
        command.Parameters.Add(name, SqlDbType.VarChar, size).Value =
            string.IsNullOrWhiteSpace(value) ? DBNull.Value : value.Trim();
    }

    private string GetConnectionString()
    {
        //return _configuration.GetConnectionString("EncoreUnit")
        //    ?? throw new InvalidOperationException("Missing connection string: ConnectionStrings:EncoreUnit");
        return _configuration.GetConnectionString("LegalHoldAdmin_DEV")
            ?? throw new InvalidOperationException("Missing connection string: ConnectionStrings:LegalHoldAdmin_DEV");
    }

    private static LegalHoldResult ReadLegalHoldResult(SqlDataReader reader)
    {
        return new LegalHoldResult
        {
            ID = GetValue<int?>(reader, "ID", "LegalHoldID", "EJLegalHoldID") ?? 0,
            CustomerID = GetValue<int?>(reader, "CustomerID") ?? 0,
            LegalHoldName = GetValue<string?>(reader, "Name", "LegalHoldName") ?? string.Empty,
            FirstName = GetValue<string?>(reader, "FirstName") ?? string.Empty,
            MiddleName = GetValue<string?>(reader, "MiddleName") ?? string.Empty,
            LastName = GetValue<string?>(reader, "LastName") ?? string.Empty,
            AccessNumber = GetValue<string?>(
                reader,
                "AccessNumber",
                "AccessNo",
                "HostCIFKey",
                "HostCIFKeyColumn") ?? string.Empty,
            AccountNumber = GetValue<string?>(
                reader,
                "AccountNumber",
                "AccountNum",
                "AcctNumber") ?? string.Empty,
            SocialSecurityNumber = GetValue<string?>(reader, "SSN", "SocialSecurityNumber") ?? string.Empty,
            StartDate = GetValue<DateTime?>(reader, "StartDate") ?? default,
            EndDate = GetValue<DateTime?>(reader, "EndDate"),
            Active = GetValue<bool?>(reader, "Active") ?? true,
            DateCreated = GetValue<DateTime?>(reader, "DateCreated"),
            UserInserted = GetValue<string?>(reader, "UserInserted") ?? string.Empty
        };
    }

    private static T? GetValue<T>(SqlDataReader reader, params string[] columnNames)
    {
        foreach (var columnName in columnNames)
        {
            var ordinal = TryGetOrdinal(reader, columnName);
            if (ordinal < 0 || reader.IsDBNull(ordinal))
            {
                continue;
            }

            var value = reader.GetValue(ordinal);
            var targetType = Nullable.GetUnderlyingType(typeof(T)) ?? typeof(T);

            if (targetType == typeof(string))
            {
                return (T)(object)value.ToString()!;
            }

            return (T)Convert.ChangeType(value, targetType);
        }

        return default;
    }

    private static int TryGetOrdinal(SqlDataReader reader, string columnName)
    {
        for (var i = 0; i < reader.FieldCount; i++)
        {
            if (string.Equals(reader.GetName(i), columnName, StringComparison.OrdinalIgnoreCase))
            {
                return i;
            }
        }

        return -1;
    }
}
