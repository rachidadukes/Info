using LegalHoldAdmin.Models;

namespace LegalHoldAdmin.Data;

public interface ILegalHoldRepository
{
    Task<List<LegalHoldResult>> SearchLegalHoldsAsync(
        LegalHoldSearchRequest request,
        CancellationToken cancellationToken = default);

    Task<List<CustomerSearchResult>> SearchCustomersAsync(
        LegalHoldSearchRequest request,
        CancellationToken cancellationToken = default);

    Task SaveLegalHoldAsync(LegalHoldEditModel model, CancellationToken cancellationToken = default);
}
