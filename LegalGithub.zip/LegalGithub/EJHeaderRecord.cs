namespace LegalHoldAdmin.Models;

public sealed class EJHeaderRecord
{
    public int RecordID { get; set; }
    public string BranchNumber { get; set; } = string.Empty;
    public int BranchID { get; set; }
    public string UserID { get; set; } = string.Empty;
    public short TranNo { get; set; }
    public string TranName { get; set; } = string.Empty;
    public int TranID { get; set; }
    public DateTime EJTime { get; set; }
    public DateTime CalendarDate { get; set; }
    public bool EnterpriseStatus { get; set; }
    public bool HostStatus { get; set; }
    public bool HostApproved { get; set; }
    public bool HostTimeOut { get; set; }
    public short ForwardToHost { get; set; }
    public bool ForwardToHostApproved { get; set; }
    public bool ForwardToHostTimeOut { get; set; }
    public int CustomerID { get; set; }
    public int MultiTranNumber { get; set; }
    public string AccountNumber { get; set; } = string.Empty;
    public decimal TranAmount { get; set; }
    public string Passbook { get; set; } = string.Empty;
    public DateTime BeginTime { get; set; }
    public int CashBoxID { get; set; }
    public bool CashAccumInd { get; set; }
    public short? DeferredStatus { get; set; }
    public short? TranCommitted { get; set; }
    public bool SigCaptured { get; set; }
    public string? AccessNo { get; set; }
}
