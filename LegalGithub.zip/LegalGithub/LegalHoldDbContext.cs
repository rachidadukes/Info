using LegalHoldAdmin.Models;
using Microsoft.EntityFrameworkCore;

namespace LegalHoldAdmin.Data;

public sealed class LegalHoldDbContext(DbContextOptions<LegalHoldDbContext> options)
    : DbContext(options)
{
    public DbSet<EJHeaderRecord> EJHeaders => Set<EJHeaderRecord>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        var entity = modelBuilder.Entity<EJHeaderRecord>();

        entity.ToTable("EJHeader", "dbo");
        entity.HasKey(row => row.RecordID);
        entity.Property(row => row.RecordID).ValueGeneratedOnAdd();
        entity.Property(row => row.BranchNumber).HasMaxLength(20).IsUnicode(false);
        entity.Property(row => row.UserID).HasColumnName("userID").HasMaxLength(50).IsUnicode(false);
        entity.Property(row => row.TranName).HasMaxLength(40).IsUnicode(false);
        entity.Property(row => row.AccountNumber).HasMaxLength(20).IsUnicode(false);
        entity.Property(row => row.TranAmount).HasColumnType("money");
        entity.Property(row => row.Passbook).HasMaxLength(1).IsUnicode(false);
        entity.Property(row => row.AccessNo).HasMaxLength(14);
    }
}
