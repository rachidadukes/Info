namespace EncoreAuthDemo.Authorization;

public interface IRoleMapper
{
    EncoreRoleMatch? Map(IReadOnlyCollection<string> activeDirectoryGroups);
}
