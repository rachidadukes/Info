namespace EncoreAuthDemo.Authorization;

public static class EncorePolicies
{
    public const string AdminOnly = "Encore.AdminOnly";
    public const string SupervisorOnly = "Encore.SupervisorOnly";
    public const string TellerOnly = "Encore.TellerOnly";
}
