namespace EncoreAuthDemo.Authorization;

public static class EncoreRoles
{
    public const string Admin = "Admin";
    public const string Supervisor = "Supervisor";
    public const string Teller = "Teller";
}
