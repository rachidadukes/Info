using EncoreAuthDemo.Components;
using EncoreAuthDemo.Authentication;
using EncoreAuthDemo.Authorization;
using EncoreAuthDemo.Options;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.DataProtection;

var builder = WebApplication.CreateBuilder(args);

builder.Logging.ClearProviders();
builder.Logging.AddConsole();
builder.Logging.AddDebug();

// Add services to the container.
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

builder.Services.Configure<ActiveDirectoryOptions>(
    builder.Configuration.GetSection(ActiveDirectoryOptions.SectionName));
builder.Services.Configure<EncoreAuthorizationOptions>(
    builder.Configuration.GetSection(EncoreAuthorizationOptions.SectionName));

var dataProtection = builder.Services.AddDataProtection()
    .SetApplicationName("EncoreAuthDemo");

if (builder.Environment.IsDevelopment())
{
    dataProtection.PersistKeysToFileSystem(new DirectoryInfo(Path.Combine(
        builder.Environment.ContentRootPath,
        "App_Data",
        "DataProtectionKeys")));
}

builder.Services.AddHttpContextAccessor();
builder.Services.AddCascadingAuthenticationState();
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.Cookie.Name = "EncoreAuthDemo.Auth";
        options.Cookie.HttpOnly = true;
        options.Cookie.SameSite = SameSiteMode.Strict;
        options.Cookie.SecurePolicy = CookieSecurePolicy.Always;
        options.LoginPath = "/login";
        options.LogoutPath = "/logout";
        options.AccessDeniedPath = "/access-denied";
        options.SlidingExpiration = true;
        options.ExpireTimeSpan = TimeSpan.FromMinutes(30);
    });
builder.Services.AddAuthorization(options =>
{
    options.AddPolicy(EncorePolicies.AdminOnly, policy => policy.RequireRole(EncoreRoles.Admin));
    options.AddPolicy(EncorePolicies.SupervisorOnly, policy => policy.RequireRole(EncoreRoles.Supervisor));
    options.AddPolicy(EncorePolicies.TellerOnly, policy => policy.RequireRole(EncoreRoles.Teller));
});

builder.Services.AddScoped<EncoreAuthDemo.Authentication.IAuthenticationService, ActiveDirectoryAuthenticationService>();
builder.Services.AddSingleton<IRoleMapper, EncoreRoleMapper>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();

app.UseAuthentication();
app.UseAuthorization();

app.UseAntiforgery();

app.MapPost("/auth/logout", async (HttpContext httpContext) =>
{
    await httpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
    return Results.Redirect("/");
}).RequireAuthorization();

app.MapStaticAssets();
app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();
