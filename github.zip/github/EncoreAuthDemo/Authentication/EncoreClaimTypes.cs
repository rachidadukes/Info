namespace EncoreAuthDemo.Authentication;

public static class EncoreClaimTypes
{
    public const string EmployeeId = "encore:employee_id";
    public const string DisplayName = "encore:display_name";
    public const string DistinguishedName = "encore:distinguished_name";
    public const string MatchedAdGroup = "encore:matched_ad_group";
    public const string LegacyAuthorityLevel = "encore:legacy_authority_level";
}
