using EncoreAuthDemo.Models;

namespace EncoreAuthDemo.Authentication;

public interface IAuthenticationService
{
    Task<AuthenticationResult> AuthenticateAsync(
        string employeeId,
        string password,
        CancellationToken cancellationToken = default);
}
