using EncoreAuthDemo.Models;

namespace EncoreAuthDemo.Authentication;

public sealed record AuthenticationResult
{
    private AuthenticationResult(bool succeeded, EncoreUser? user, string? failureReason)
    {
        Succeeded = succeeded;
        User = user;
        FailureReason = failureReason;
    }

    public bool Succeeded { get; }

    public EncoreUser? User { get; }

    public string? FailureReason { get; }

    public static AuthenticationResult Success(EncoreUser user) => new(true, user, null);

    public static AuthenticationResult Failed(string failureReason) => new(false, null, failureReason);
}
