namespace EncoreAuthDemo.Options;

public sealed class EncoreGroupMapping
{
    public string GroupName { get; init; } = string.Empty;

    public string DistinguishedName { get; init; } = string.Empty;

    public string Role { get; init; } = string.Empty;

    public int LegacyAuthorityLevel { get; init; }

    public int Precedence { get; init; }
}
