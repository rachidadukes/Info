namespace EncoreAuthDemo.Options;

public sealed class EncoreAuthorizationOptions
{
    public const string SectionName = "EncoreAuthorization";

    public IReadOnlyList<EncoreGroupMapping> GroupMappings { get; init; } = [];
}
