using System.DirectoryServices.Protocols;

namespace EncoreAuthDemo.Options;

public sealed class ActiveDirectoryOptions
{
    public const string SectionName = "ActiveDirectory";

    public string Server { get; init; } = string.Empty;

    public int Port { get; init; } = 389;

    public bool UseSsl { get; init; }

    public string Domain { get; init; } = string.Empty;

    public string BindUserNameFormat { get; init; } = string.Empty;

    public string SearchBaseDn { get; init; } = string.Empty;

    public string EmployeeIdAttribute { get; init; } = "sAMAccountName";

    public string DisplayNameAttribute { get; init; } = "displayName";

    public string GroupMembershipAttribute { get; init; } = "memberOf";

    public AuthType AuthType { get; init; } = AuthType.Negotiate;
}
