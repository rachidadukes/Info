namespace EncoreAuthDemo.Authentication;

public enum AuthenticationFailureCode
{
    None,
    AuthenticationFailed,
    MissingCredentials,
    NotConfigured,
    InvalidCredentials,
    DirectoryUnavailable,
    UserNotFound,
    DirectorySearchFailed,
    NoMappedRole
}
