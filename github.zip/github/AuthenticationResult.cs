using EncoreAuthDemo.Models;

namespace EncoreAuthDemo.Authentication;

public sealed record AuthenticationResult
{
    private AuthenticationResult(
        bool succeeded,
        EncoreUser? user,
        AuthenticationFailureCode failureCode,
        string? failureReason)
    {
        Succeeded = succeeded;
        User = user;
        FailureCode = failureCode;
        FailureReason = failureReason;
    }

    public bool Succeeded { get; }

    public EncoreUser? User { get; }

    public AuthenticationFailureCode FailureCode { get; }

    public string? FailureReason { get; }

    public static AuthenticationResult Success(EncoreUser user) =>
        new(true, user, AuthenticationFailureCode.None, null);

    public static AuthenticationResult Failed(
        AuthenticationFailureCode failureCode,
        string failureReason) => new(false, null, failureCode, failureReason);
}
